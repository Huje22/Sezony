Screeny z sezonu 9
